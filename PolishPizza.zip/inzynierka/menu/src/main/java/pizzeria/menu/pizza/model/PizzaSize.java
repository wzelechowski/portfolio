package pizzeria.menu.pizza.model;

public enum PizzaSize {
    S, M, L, XL
}
