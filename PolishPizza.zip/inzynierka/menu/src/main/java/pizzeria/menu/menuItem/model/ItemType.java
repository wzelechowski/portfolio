package pizzeria.menu.menuItem.model;

public enum ItemType {
    PIZZA, DRINK, EXTRA
}
