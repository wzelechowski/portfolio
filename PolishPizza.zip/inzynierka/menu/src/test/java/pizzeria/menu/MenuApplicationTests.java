package pizzeria.menu;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MenuApplicationTests {

//	@Test
//    @Disabled
//	void contextLoads() {
//	}

}
