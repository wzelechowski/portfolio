package pizzeria.promotions.promotionProposalProduct.model;

public enum ProposalProductRole {
    ANTECEDENT, CONSEQUENT
}
