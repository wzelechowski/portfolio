package pizzeria.promotions.promotionProposal.dto.request;

public record PromotionProposalPatchRequest(
        Boolean approved
) {
}
