package pizzeria.promotions.promotionProposal.model;

public enum EffectType {
    PERCENT, FIXED, FREE_PRODUCT
}
