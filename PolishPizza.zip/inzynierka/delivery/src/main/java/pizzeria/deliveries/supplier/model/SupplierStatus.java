package pizzeria.deliveries.supplier.model;

public enum SupplierStatus {
    AVAILABLE, BUSY, OFFLINE
}
