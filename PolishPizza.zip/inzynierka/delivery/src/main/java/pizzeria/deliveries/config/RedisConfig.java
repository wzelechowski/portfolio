package pizzeria.deliveries.config;

public class RedisConfig {
}
