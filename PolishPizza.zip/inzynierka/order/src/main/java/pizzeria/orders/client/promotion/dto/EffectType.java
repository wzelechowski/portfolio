package pizzeria.orders.client.promotion.dto;

public enum EffectType {
    PERCENT, FIXED, FREE_PRODUCT
}
