package pizzeria.orders.order.model;

public enum OrderType {
    ON_SITE, TAKE_AWAY, DELIVERY
}
