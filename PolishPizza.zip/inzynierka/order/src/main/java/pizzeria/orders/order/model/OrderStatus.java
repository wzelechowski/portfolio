package pizzeria.orders.order.model;

public enum OrderStatus {
    NEW, IN_PREPARATION, READY, DELIVERY, COMPLETED, CANCELLED
}
