package pizzeria.orders.order.model;

public enum DeliveryStatus {
    PICKED_UP, DELIVERED, CANCELLED
}

