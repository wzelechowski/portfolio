package pizzeria.user.userProfile.model;

public enum Role {
    ROLE_CLIENT, ROLE_SUPPLIER
}
