package pizzeria.user.userProfile.dto.request;

public record RefreshTokenRequest(
        String refreshToken
) {
}
